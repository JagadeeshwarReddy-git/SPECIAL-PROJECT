import streamlit as st
import pandas as pd

from services.analyzer import analyze_text
from views.history import save_history


def _sentiment_label(value):
    value = str(value).strip().lower()
    return {
        "positive": "Positive",
        "neutral": "Neutral",
        "negative": "Negative",
    }.get(value, value.capitalize())


def _metric_card(title, value, icon):
    st.markdown(
        f"""
        <div class="csv-metric-card">
            <div class="csv-metric-icon">{icon}</div>
            <div class="csv-metric-label">{title}</div>
            <div class="csv-metric-value">{value}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def show():
    st.markdown(
        """
        <style>
        /* =====================================================
           CSV UPLOAD — clean application-style UI
           ===================================================== */

        .csv-title {
            font-size: 32px;
            font-weight: 700;
            margin: 8px 0 4px;
            letter-spacing: -0.5px;
        }

        .csv-subtitle {
            color: #64748b;
            font-size: 15px;
            margin-bottom: 24px;
        }

        .csv-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 21px;
            margin-bottom: 20px;
        }

        .csv-card-title {
            font-size: 18px;
            font-weight: 650;
            margin-bottom: 5px;
        }

        .csv-card-text {
            color: #64748b;
            font-size: 13px;
            line-height: 1.5;
        }

        .csv-section {
            font-size: 20px;
            font-weight: 700;
            margin: 27px 0 13px;
        }

        .csv-metric-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 17px;
            min-height: 120px;
        }

        .csv-metric-icon {
            font-size: 22px;
            margin-bottom: 8px;
        }

        .csv-metric-label {
            color: #64748b;
            font-size: 12px;
        }

        .csv-metric-value {
            font-size: 23px;
            font-weight: 700;
            margin-top: 4px;
        }

        .csv-info {
            border-left: 3px solid #3b82f6;
            background: #f8fafc;
            padding: 13px 16px;
            border-radius: 6px;
            color: #475569;
            font-size: 13px;
            line-height: 1.5;
        }

        .csv-success {
            border: 1px solid #bbf7d0;
            background: #f0fdf4;
            color: #166534;
            padding: 11px 14px;
            border-radius: 8px;
            font-size: 13px;
            margin-top: 16px;
        }

        @media (prefers-color-scheme: dark) {
            .csv-card,
            .csv-metric-card {
                background: #111827;
                border-color: #334155;
            }

            .csv-subtitle,
            .csv-card-text,
            .csv-metric-label {
                color: #94a3b8;
            }

            .csv-info {
                background: #111827;
                color: #cbd5e1;
            }

            .csv-success {
                background: #052e16;
                border-color: #166534;
                color: #bbf7d0;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # ---------------------------------------------------------
    # Header
    # ---------------------------------------------------------
    st.markdown(
        '<div class="csv-title">📄 CSV Upload</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="csv-subtitle">'
        'Upload a text dataset and analyze sentiment, emotion, and audience patterns.'
        '</div>',
        unsafe_allow_html=True,
    )

    # ---------------------------------------------------------
    # Upload
    # ---------------------------------------------------------
    st.markdown(
        """
        <div class="csv-card">
            <div class="csv-card-title">Upload your dataset</div>
            <div class="csv-card-text">
                CSV files should contain at least one column with text such as
                comments, reviews, feedback, or messages.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    uploaded_file = st.file_uploader(
        "Choose a CSV file",
        type=["csv"],
        help="Upload a CSV containing a text column.",
    )

    if uploaded_file is None:
        st.markdown(
            """
            <div class="csv-info" style="margin-top:14px;">
                <strong>Tip:</strong> If your CSV has multiple columns,
                the application will try to identify the text column automatically.
                You can change it after uploading.
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    # ---------------------------------------------------------
    # Read CSV
    # ---------------------------------------------------------
    try:
        df = pd.read_csv(uploaded_file)
    except UnicodeDecodeError:
        try:
            uploaded_file.seek(0)
            df = pd.read_csv(uploaded_file, encoding="latin-1")
        except Exception as e:
            st.error(f"Could not read the CSV file.\n\n{e}")
            return
    except Exception as e:
        st.error(f"Could not read the CSV file.\n\n{e}")
        return

    if df.empty:
        st.warning("The uploaded CSV is empty.")
        return

    # ---------------------------------------------------------
    # Dataset overview
    # ---------------------------------------------------------
    st.markdown(
        '<div class="csv-section">📋 Dataset overview</div>',
        unsafe_allow_html=True,
    )

    missing_cells = int(df.isna().sum().sum())
    duplicate_rows = int(df.duplicated().sum())

    m1, m2, m3, m4 = st.columns(4)

    with m1:
        _metric_card("Rows", f"{len(df):,}", "📄")

    with m2:
        _metric_card("Columns", f"{len(df.columns):,}", "▦")

    with m3:
        _metric_card("Missing cells", f"{missing_cells:,}", "⚠️")

    with m4:
        _metric_card("Duplicate rows", f"{duplicate_rows:,}", "♻️")

    # ---------------------------------------------------------
    # Select text column
    # ---------------------------------------------------------
    possible_names = [
        "text",
        "comment",
        "comments",
        "content",
        "review",
        "reviews",
        "message",
        "feedback",
        "description",
    ]

    lower_map = {str(col).strip().lower(): col for col in df.columns}

    detected_column = None

    for name in possible_names:
        if name in lower_map:
            detected_column = lower_map[name]
            break

    if detected_column is None:
        object_columns = df.select_dtypes(include=["object", "string"]).columns.tolist()

        if len(object_columns) == 1:
            detected_column = object_columns[0]
        elif object_columns:
            detected_column = max(
                object_columns,
                key=lambda col: df[col].dropna().astype(str).str.len().mean()
                if not df[col].dropna().empty
                else 0
            )

    if detected_column is None:
        st.error(
            "No text column could be identified. "
            "Your CSV needs at least one text-based column."
        )
        st.dataframe(df.head(10), use_container_width=True, hide_index=True)
        return

    text_column = st.selectbox(
        "Text column",
        options=list(df.columns),
        index=list(df.columns).index(detected_column),
        help="Select the column containing comments, reviews, feedback, or other text.",
    )

    # ---------------------------------------------------------
    # Preview
    # ---------------------------------------------------------
    st.markdown(
        '<div class="csv-section">👀 Data preview</div>',
        unsafe_allow_html=True,
    )

    st.dataframe(
        df.head(10),
        use_container_width=True,
        hide_index=True,
    )

    # ---------------------------------------------------------
    # Analysis settings
    # ---------------------------------------------------------
    st.markdown(
        '<div class="csv-section">⚙️ Analysis settings</div>',
        unsafe_allow_html=True,
    )

    available_rows = len(df)

    max_rows = st.number_input(
        "Number of rows to analyze",
        min_value=1,
        max_value=available_rows,
        value=min(100, available_rows),
        step=1,
        help="Analyzing fewer rows is useful for large CSV files.",
    )

    st.caption(
        f"Selected text column: **{text_column}** • "
        f"Rows available: **{available_rows:,}** • "
        f"Rows selected: **{int(max_rows):,}**"
    )

    analyze_clicked = st.button(
        "🔍 Analyze CSV",
        use_container_width=True,
        type="primary",
    )

    if not analyze_clicked:
        return

    # ---------------------------------------------------------
    # Prepare selected rows
    # ---------------------------------------------------------
    work_df = df.head(int(max_rows)).copy()

    work_df[text_column] = (
        work_df[text_column]
        .fillna("")
        .astype(str)
        .str.strip()
    )

    before = len(work_df)
    work_df = work_df[work_df[text_column] != ""].copy()
    removed_empty = before - len(work_df)

    if work_df.empty:
        st.warning("No usable text was found in the selected rows.")
        return

    # ---------------------------------------------------------
    # Analyze
    # ---------------------------------------------------------
    results = []

    progress = st.progress(0)
    total = len(work_df)

    with st.spinner("Analyzing the selected records..."):
        for index, (_, row) in enumerate(work_df.iterrows()):
            current_text = row[text_column]

            try:
                result = analyze_text(current_text)

                sentiment = str(result.get("sentiment", "unknown"))
                sentiment_score = float(result.get("sentiment_score", 0.0))
                emotion = str(result.get("emotion", "unknown"))
                emotion_score = float(result.get("emotion_score", 0.0))

            except Exception:
                sentiment = "unknown"
                sentiment_score = 0.0
                emotion = "unknown"
                emotion_score = 0.0

            record = row.to_dict()
            record["text"] = current_text
            record["sentiment"] = sentiment
            record["sentiment_score"] = sentiment_score
            record["emotion"] = emotion
            record["emotion_score"] = emotion_score

            results.append(record)

            progress.progress((index + 1) / total)

    progress.empty()

    result_df = pd.DataFrame(results)

    if result_df.empty:
        st.warning("No records could be analyzed.")
        return

    # ---------------------------------------------------------
    # Save to shared analysis state
    # ---------------------------------------------------------
    st.session_state.analysis_df = result_df
    st.session_state.csv_filename = uploaded_file.name

    # ---------------------------------------------------------
    # Results
    # ---------------------------------------------------------
    st.markdown(
        '<div class="csv-section">📊 Analysis results</div>',
        unsafe_allow_html=True,
    )

    sentiments = (
        result_df["sentiment"]
        .astype(str)
        .str.strip()
        .str.lower()
    )

    positive = int((sentiments == "positive").sum())
    neutral = int((sentiments == "neutral").sum())
    negative = int((sentiments == "negative").sum())
    unknown = int((sentiments == "unknown").sum())

    emotions = (
        result_df["emotion"]
        .astype(str)
        .str.strip()
        .str.lower()
    )
    valid_emotions = emotions[emotions != "unknown"]

    dominant_sentiment = (
        sentiments[sentiments.isin(["positive", "neutral", "negative"])]
        .mode()
        .iloc[0]
        if not sentiments[sentiments.isin(["positive", "neutral", "negative"])].empty
        else "unknown"
    )

    dominant_emotion = (
        valid_emotions.mode().iloc[0]
        if not valid_emotions.empty
        else "unknown"
    )

    avg_sentiment_conf = pd.to_numeric(
        result_df["sentiment_score"], errors="coerce"
    ).mean()

    avg_emotion_conf = pd.to_numeric(
        result_df["emotion_score"], errors="coerce"
    ).mean()

    r1, r2, r3, r4 = st.columns(4)

    with r1:
        _metric_card("Analyzed", f"{len(result_df):,}", "📄")

    with r2:
        _metric_card("Positive", f"{positive:,}", "😊")

    with r3:
        _metric_card("Neutral", f"{neutral:,}", "😐")

    with r4:
        _metric_card("Negative", f"{negative:,}", "😟")

    # ---------------------------------------------------------
    # Result summary
    # ---------------------------------------------------------
    st.markdown(
        '<div class="csv-section">💡 Analysis summary</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        f"""
        <div class="csv-info">
            <strong>Dominant sentiment:</strong> {_sentiment_label(dominant_sentiment)}
            &nbsp;&nbsp; • &nbsp;&nbsp;
            <strong>Dominant emotion:</strong> {str(dominant_emotion).capitalize()}
            &nbsp;&nbsp; • &nbsp;&nbsp;
            <strong>Average sentiment confidence:</strong> {avg_sentiment_conf:.1%}
            &nbsp;&nbsp; • &nbsp;&nbsp;
            <strong>Average emotion confidence:</strong> {avg_emotion_conf:.1%}
        </div>
        """,
        unsafe_allow_html=True,
    )

    if removed_empty:
        st.caption(
            f"{removed_empty:,} selected row(s) with empty text were skipped."
        )

    if unknown:
        st.caption(
            f"{unknown:,} record(s) returned an unknown sentiment result."
        )

    # ---------------------------------------------------------
    # Charts
    # ---------------------------------------------------------
    st.markdown(
        '<div class="csv-section">📈 Audience reaction</div>',
        unsafe_allow_html=True,
    )

    chart1, chart2 = st.columns(2)

    with chart1:
        st.markdown("**Sentiment distribution**")
        sentiment_counts = (
            sentiments
            .value_counts()
            .reindex(["positive", "neutral", "negative", "unknown"])
            .fillna(0)
            .astype(int)
        )
        st.bar_chart(sentiment_counts)

    with chart2:
        st.markdown("**Top emotions**")
        emotion_counts = emotions.value_counts().head(8)
        st.bar_chart(emotion_counts)

    # ---------------------------------------------------------
    # Results table
    # ---------------------------------------------------------
    st.markdown(
        '<div class="csv-section">📝 Analyzed records</div>',
        unsafe_allow_html=True,
    )

    preferred = [
        text_column,
        "text",
        "sentiment",
        "sentiment_score",
        "emotion",
        "emotion_score",
    ]

    display_columns = []
    for column in preferred:
        if column in result_df.columns and column not in display_columns:
            display_columns.append(column)

    # Keep other original columns after the main analysis columns.
    for column in result_df.columns:
        if column not in display_columns:
            display_columns.append(column)

    st.dataframe(
        result_df[display_columns],
        use_container_width=True,
        hide_index=True,
    )

    # ---------------------------------------------------------
    # Download
    # ---------------------------------------------------------
    csv_bytes = result_df.to_csv(index=False).encode("utf-8")

    st.download_button(
        "⬇️ Download analyzed CSV",
        data=csv_bytes,
        file_name=f"analyzed_{uploaded_file.name}",
        mime="text/csv",
        use_container_width=True,
    )

    # ---------------------------------------------------------
    # History
    # ---------------------------------------------------------
    save_history(
        analysis_type="CSV",
        records_count=len(result_df),
        sentiment=_sentiment_label(dominant_sentiment),
        emotion=str(dominant_emotion).capitalize(),
        source_name=uploaded_file.name,
    )

    st.markdown(
        """
        <div class="csv-success">
            ✓ CSV analysis completed successfully and saved to History.
        </div>
        """,
        unsafe_allow_html=True,
    )


show_csv = show
show = show