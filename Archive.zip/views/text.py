import streamlit as st
import pandas as pd

from services.analyzer import analyze_text
from views.history import save_history


def _sentiment_label(value):
    value = str(value).lower()
    if value == "positive":
        return "Positive"
    if value == "negative":
        return "Negative"
    if value == "neutral":
        return "Neutral"
    return value.capitalize()


def _result_card(title, value, confidence, icon):
    st.markdown(
        f"""
        <div class="text-result-card">
            <div class="text-result-icon">{icon}</div>
            <div class="text-result-label">{title}</div>
            <div class="text-result-value">{value}</div>
            <div class="text-result-confidence">
                Confidence&nbsp;&nbsp; <strong>{confidence:.1%}</strong>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def show():
    st.markdown(
        """
        <style>
        /* =====================================================
           TEXT ANALYZER — clean application-style UI
           ===================================================== */

        .text-page-title {
            font-size: 32px;
            font-weight: 700;
            margin: 8px 0 4px;
            letter-spacing: -0.5px;
        }

        .text-page-subtitle {
            color: #64748b;
            font-size: 15px;
            margin-bottom: 24px;
        }

        .text-input-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 22px;
            margin-bottom: 22px;
        }

        .text-card-title {
            font-size: 18px;
            font-weight: 650;
            margin-bottom: 5px;
        }

        .text-card-description {
            color: #64748b;
            font-size: 13px;
            margin-bottom: 14px;
        }

        .text-result-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 19px;
            min-height: 145px;
        }

        .text-result-icon {
            font-size: 23px;
            margin-bottom: 9px;
        }

        .text-result-label {
            color: #64748b;
            font-size: 12px;
            margin-bottom: 5px;
        }

        .text-result-value {
            font-size: 21px;
            font-weight: 700;
        }

        .text-result-confidence {
            color: #64748b;
            font-size: 11px;
            margin-top: 9px;
        }

        .text-section-title {
            font-size: 20px;
            font-weight: 700;
            margin: 27px 0 13px;
        }

        .text-analysis-box {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
        }

        .text-analysis-label {
            color: #64748b;
            font-size: 12px;
            margin-bottom: 8px;
        }

        .text-analysis-content {
            font-size: 15px;
            line-height: 1.65;
            white-space: pre-wrap;
        }

        .text-info {
            border-left: 3px solid #3b82f6;
            background: #f8fafc;
            padding: 13px 16px;
            border-radius: 6px;
            color: #475569;
            font-size: 13px;
            line-height: 1.5;
        }

        .text-success {
            border: 1px solid #bbf7d0;
            background: #f0fdf4;
            color: #166534;
            padding: 11px 14px;
            border-radius: 8px;
            font-size: 13px;
            margin-top: 14px;
        }

        @media (prefers-color-scheme: dark) {
            .text-input-card,
            .text-result-card,
            .text-analysis-box {
                background: #111827;
                border-color: #334155;
            }

            .text-page-subtitle,
            .text-card-description,
            .text-result-label,
            .text-result-confidence,
            .text-analysis-label {
                color: #94a3b8;
            }

            .text-info {
                background: #111827;
                color: #cbd5e1;
            }

            .text-success {
                background: #052e16;
                border-color: #166534;
                color: #bbf7d0;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # ---------------------------------------------------------
    # Header
    # ---------------------------------------------------------
    st.markdown(
        '<div class="text-page-title">✍️ Text Analyzer</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="text-page-subtitle">'
        'Enter a sentence, comment, review, or short piece of text to analyze its sentiment and emotion.'
        '</div>',
        unsafe_allow_html=True,
    )

    # ---------------------------------------------------------
    # Input
    # ---------------------------------------------------------
    st.markdown(
        """
        <div class="text-input-card">
            <div class="text-card-title">Enter text to analyze</div>
            <div class="text-card-description">
                The text will be processed using the project's sentiment and emotion models.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    text = st.text_area(
        "Text",
        placeholder=(
            "Example: I really enjoyed this product. "
            "The quality is excellent and I would definitely recommend it."
        ),
        height=190,
        label_visibility="collapsed",
    )

    char_count = len(text.strip())
    word_count = len(text.split()) if text.strip() else 0

    c1, c2 = st.columns([1, 1])

    with c1:
        st.caption(f"Characters: {char_count:,}")

    with c2:
        st.caption(f"Words: {word_count:,}")

    analyze_clicked = st.button(
        "🔍 Analyze Text",
        use_container_width=True,
        type="primary",
    )

    if not analyze_clicked:
        st.markdown(
            """
            <div class="text-info" style="margin-top:18px;">
                <strong>Tip:</strong> Try a complete sentence or a short review
                for a more meaningful result.
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    # ---------------------------------------------------------
    # Validation
    # ---------------------------------------------------------
    if not text.strip():
        st.warning("Please enter some text before starting the analysis.")
        return

    # ---------------------------------------------------------
    # Analysis
    # ---------------------------------------------------------
    try:
        with st.spinner("Analyzing your text..."):
            result = analyze_text(text.strip())

        sentiment = str(result.get("sentiment", "neutral")).lower()
        sentiment_score = float(result.get("sentiment_score", 0.0))

        emotion = str(result.get("emotion", "neutral"))
        emotion_score = float(result.get("emotion_score", 0.0))

    except Exception as e:
        st.error(
            "The text could not be analyzed right now.\n\n"
            f"{e}"
        )
        return

    # ---------------------------------------------------------
    # Save current analysis so other modules can use it
    # ---------------------------------------------------------
    df = pd.DataFrame(
        [
            {
                "text": text.strip(),
                "sentiment": sentiment,
                "sentiment_score": sentiment_score,
                "emotion": emotion,
                "emotion_score": emotion_score,
            }
        ]
    )

    st.session_state.analysis_df = df

    # ---------------------------------------------------------
    # Results
    # ---------------------------------------------------------
    st.markdown(
        '<div class="text-section-title">📊 Analysis Results</div>',
        unsafe_allow_html=True,
    )

    r1, r2 = st.columns(2)

    with r1:
        sentiment_icon = {
            "positive": "😊",
            "negative": "😟",
            "neutral": "😐",
        }.get(sentiment, "🔎")

        _result_card(
            "Sentiment",
            _sentiment_label(sentiment),
            sentiment_score,
            sentiment_icon,
        )

    with r2:
        _result_card(
            "Emotion",
            emotion.capitalize(),
            emotion_score,
            "🎭",
        )

    # ---------------------------------------------------------
    # Original text
    # ---------------------------------------------------------
    st.markdown(
        '<div class="text-section-title">📝 Analyzed Text</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        f"""
        <div class="text-analysis-box">
            <div class="text-analysis-label">Your input</div>
            <div class="text-analysis-content">{text.strip()}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ---------------------------------------------------------
    # Interpretation
    # ---------------------------------------------------------
    st.markdown(
        '<div class="text-section-title">💡 Result Overview</div>',
        unsafe_allow_html=True,
    )

    sentiment_text = _sentiment_label(sentiment)
    emotion_text = emotion.capitalize()

    st.markdown(
        f"""
        <div class="text-info">
            The model classified the text as <strong>{sentiment_text}</strong>
            with a confidence of <strong>{sentiment_score:.1%}</strong>.
            The detected dominant emotion is <strong>{emotion_text}</strong>
            with a confidence of <strong>{emotion_score:.1%}</strong>.
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ---------------------------------------------------------
    # Technical result
    # ---------------------------------------------------------
    with st.expander("🔎 View model output"):
        st.json(
            {
                "sentiment": sentiment,
                "sentiment_score": round(sentiment_score, 4),
                "emotion": emotion,
                "emotion_score": round(emotion_score, 4),
            }
        )

    # ---------------------------------------------------------
    # History
    # ---------------------------------------------------------
    save_history(
        analysis_type="Text",
        records_count=1,
        sentiment=sentiment_text,
        emotion=emotion_text,
        source_name=text.strip()[:80],
    )

    st.markdown(
        """
        <div class="text-success">
            ✓ Analysis completed successfully and saved to History.
        </div>
        """,
        unsafe_allow_html=True,
    )


show_text = show
show = show