import streamlit as st
import pandas as pd
import plotly.express as px


# ==========================================================
# Helper Functions
# ==========================================================

def normalize_sentiment(series):
    return (
        series.astype(str)
        .str.strip()
        .str.lower()
        .replace({
            "pos": "positive",
            "neg": "negative",
            "neu": "neutral"
        })
    )


def find_text_column(df):
    possible_columns = [
        "comment",
        "comments",
        "text",
        "content",
        "review",
        "reviews",
        "message",
        "feedback",
        "clean_comment"
    ]

    for column in possible_columns:
        if column in df.columns:
            return column

    return None


def confidence_percent(series):

    values = pd.to_numeric(
        series,
        errors="coerce"
    ).dropna()

    if values.empty:
        return None

    average = values.mean()

    # Hugging Face normally returns 0–1
    if average <= 1:
        return average * 100

    return average


def style_chart(fig, height=390):

    fig.update_layout(
        height=height,
        margin=dict(
            l=20,
            r=20,
            t=65,
            b=25
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        title=dict(
            x=0.02,
            xanchor="left"
        )
    )

    return fig


# ==========================================================
# Main Analytics Page
# ==========================================================

def show():

    # ======================================================
    # Header
    # ======================================================

    st.title("📊 Analytics")

    st.caption(
        "Understand your analyzed audience through clear "
        "statistics, sentiment, emotions and feedback."
    )

    # ======================================================
    # Get Analysis Data
    # ======================================================

    df = st.session_state.get("analysis_df")

    # ------------------------------------------------------
    # No data
    # ------------------------------------------------------

    if df is None:

        st.info(
            "📂 **No analysis has been completed yet.**\n\n"
            "Go to **YouTube Analyzer**, **Text Analyzer**, "
            "or **CSV Upload**, complete an analysis, "
            "and then return here."
        )

        return

    # ------------------------------------------------------
    # Validate DataFrame
    # ------------------------------------------------------

    if not isinstance(df, pd.DataFrame):

        st.error(
            "❌ The current analysis data is not a valid DataFrame."
        )

        return

    # ------------------------------------------------------
    # Empty DataFrame
    # ------------------------------------------------------

    if df.empty:

        st.info(
            "📂 **The current analysis contains no records.**\n\n"
            "Please analyze some data first."
        )

        return

    # ------------------------------------------------------
    # Check sentiment
    # ------------------------------------------------------

    if "sentiment" not in df.columns:

        st.warning(
            "⚠️ The current dataset does not contain "
            "sentiment results."
        )

        st.dataframe(
            df.head(20),
            use_container_width=True,
            hide_index=True
        )

        return

    # ======================================================
    # Work on Copy
    # ======================================================

    data = df.copy()

    data["sentiment_normalized"] = normalize_sentiment(
        data["sentiment"]
    )

    # ======================================================
    # Basic Statistics
    # ======================================================

    total = len(data)

    positive = int(
        (
            data["sentiment_normalized"]
            == "positive"
        ).sum()
    )

    neutral = int(
        (
            data["sentiment_normalized"]
            == "neutral"
        ).sum()
    )

    negative = int(
        (
            data["sentiment_normalized"]
            == "negative"
        ).sum()
    )

    # ======================================================
    # Percentages
    # ======================================================

    positive_pct = (
        positive / total * 100
    )

    neutral_pct = (
        neutral / total * 100
    )

    negative_pct = (
        negative / total * 100
    )

    # ======================================================
    # Dominant Sentiment
    # ======================================================

    dominant_sentiment = (
        data[
            "sentiment_normalized"
        ]
        .value_counts()
        .idxmax()
        .title()
    )

    # ======================================================
    # Source
    # ======================================================

    source = (
        st.session_state.get("youtube_title")
        or
        st.session_state.get("csv_filename")
    )

    if source:

        st.caption(
            f"📁 Current source: **{str(source)[:100]}**"
        )

    # ======================================================
    # KPI SECTION
    # ======================================================

    st.subheader("📌 Analysis Overview")

    c1, c2, c3, c4 = st.columns(4)

    with c1:

        st.metric(
            "Total Records",
            f"{total:,}"
        )

    with c2:

        st.metric(
            "😊 Positive",
            f"{positive:,}",
            f"{positive_pct:.1f}%"
        )

    with c3:

        st.metric(
            "😐 Neutral",
            f"{neutral:,}",
            f"{neutral_pct:.1f}%"
        )

    with c4:

        st.metric(
            "😡 Negative",
            f"{negative:,}",
            f"{negative_pct:.1f}%"
        )

    # ======================================================
    # Quick Interpretation
    # ======================================================

    st.markdown("### 🔎 What does this mean?")

    if dominant_sentiment == "Positive":

        message = (
            f"**{positive_pct:.1f}%** of the analyzed "
            "records are positive. Positive reactions "
            "are currently the largest sentiment group."
        )

    elif dominant_sentiment == "Negative":

        message = (
            f"**{negative_pct:.1f}%** of the analyzed "
            "records are negative. Negative reactions "
            "are currently the largest sentiment group."
        )

    else:

        message = (
            f"**{neutral_pct:.1f}%** of the analyzed "
            "records are neutral. Neutral reactions "
            "are currently the largest sentiment group."
        )

    st.info(message)

    # ======================================================
    # SENTIMENT ANALYSIS
    # ======================================================

    st.subheader("😊 Sentiment Analysis")

    sentiment_table = pd.DataFrame(
        {
            "Sentiment": [
                "Positive",
                "Neutral",
                "Negative"
            ],

            "Count": [
                positive,
                neutral,
                negative
            ],

            "Percentage": [
                round(positive_pct, 1),
                round(neutral_pct, 1),
                round(negative_pct, 1)
            ]
        }
    )

    left, right = st.columns(2)

    # ------------------------------------------------------
    # Pie Chart
    # ------------------------------------------------------

    with left:

        pie = px.pie(
            sentiment_table,
            names="Sentiment",
            values="Count",
            hole=0.52,
            title="Audience Sentiment Distribution"
        )

        pie.update_traces(
            textinfo="percent+label",

            hovertemplate=(
                "<b>%{label}</b><br>"
                "Records: %{value}<br>"
                "Share: %{percent}"
                "<extra></extra>"
            )
        )

        st.plotly_chart(
            style_chart(pie),
            use_container_width=True
        )

    # ------------------------------------------------------
    # Bar Chart
    # ------------------------------------------------------

    with right:

        bar = px.bar(
            sentiment_table,
            x="Sentiment",
            y="Count",
            text="Count",
            title="Sentiment Comparison"
        )

        bar.update_traces(
            textposition="outside"
        )

        bar.update_yaxes(
            title="Number of Records"
        )

        bar.update_xaxes(
            title=""
        )

        st.plotly_chart(
            style_chart(bar),
            use_container_width=True
        )

    # ------------------------------------------------------
    # Sentiment Table
    # ------------------------------------------------------

    st.dataframe(
        sentiment_table,
        use_container_width=True,
        hide_index=True
    )

    # ======================================================
    # EMOTION ANALYSIS
    # ======================================================

    if "emotion" in data.columns:

        st.subheader("🎭 Emotion Analysis")

        emotions = (
            data["emotion"]
            .astype(str)
            .str.strip()
            .str.title()
        )

        emotions = emotions.replace(
            {
                "Nan": "Unknown",
                "": "Unknown"
            }
        )

        emotion_counts = (
            emotions
            .value_counts()
            .reset_index()
        )

        emotion_counts.columns = [
            "Emotion",
            "Count"
        ]

        emotion_counts = emotion_counts[
            emotion_counts["Emotion"]
            .str.lower()
            != "unknown"
        ]

        if not emotion_counts.empty:

            emotion_left, emotion_right = st.columns(
                [1.35, 1]
            )

            # ------------------------------------------------
            # Emotion Bar Chart
            # ------------------------------------------------

            with emotion_left:

                emotion_bar = px.bar(
                    emotion_counts.sort_values(
                        "Count"
                    ),

                    x="Count",

                    y="Emotion",

                    orientation="h",

                    text="Count",

                    title="Detected Emotions"
                )

                emotion_bar.update_traces(
                    textposition="outside"
                )

                emotion_bar.update_xaxes(
                    title="Number of Records"
                )

                emotion_bar.update_yaxes(
                    title=""
                )

                st.plotly_chart(
                    style_chart(
                        emotion_bar,
                        max(
                            360,
                            55 * len(
                                emotion_counts
                            )
                        )
                    ),

                    use_container_width=True
                )

            # ------------------------------------------------
            # Emotion Pie
            # ------------------------------------------------

            with emotion_right:

                top_emotions = (
                    emotion_counts
                    .head(6)
                )

                emotion_pie = px.pie(
                    top_emotions,

                    names="Emotion",

                    values="Count",

                    hole=0.52,

                    title="Most Common Emotions"
                )

                emotion_pie.update_traces(
                    textinfo="percent+label"
                )

                st.plotly_chart(
                    style_chart(
                        emotion_pie
                    ),

                    use_container_width=True
                )

            # ------------------------------------------------
            # Emotion Table
            # ------------------------------------------------

            st.dataframe(
                emotion_counts,
                use_container_width=True,
                hide_index=True
            )

        else:

            st.info(
                "No usable emotion results are available."
            )

    # ======================================================
    # MODEL CONFIDENCE
    # ======================================================

    confidence_columns = []

    # Sentiment confidence

    for column in [
        "confidence",
        "sentiment_score"
    ]:

        if column in data.columns:

            confidence_columns.append(
                (
                    "Sentiment",
                    column
                )
            )

            break

    # Emotion confidence

    for column in [
        "emotion_score",
        "emotion_confidence"
    ]:

        if column in data.columns:

            confidence_columns.append(
                (
                    "Emotion",
                    column
                )
            )

            break

    if confidence_columns:

        st.subheader(
            "🎯 Model Confidence"
        )

        cards = st.columns(
            len(confidence_columns)
        )

        for index, (
            label,
            column
        ) in enumerate(
            confidence_columns
        ):

            confidence = confidence_percent(
                data[column]
            )

            with cards[index]:

                if confidence is None:

                    st.metric(
                        f"{label} Confidence",
                        "N/A"
                    )

                else:

                    st.metric(
                        f"Avg. {label} Confidence",
                        f"{confidence:.1f}%"
                    )

        st.caption(
            "Confidence represents how strongly the model "
            "supports its prediction. It is not the same "
            "as model accuracy."
        )

    # ======================================================
    # AUDIENCE MOOD
    # ======================================================

    st.subheader(
        "🧭 Audience Mood"
    )

    if positive_pct >= 60:

        mood = "Mostly Positive"

        explanation = (
            "Positive reactions form the clear majority "
            "of the analyzed data."
        )

    elif negative_pct >= 40:

        mood = "Mixed / Negative"

        explanation = (
            "Negative reactions represent a substantial "
            "part of the analyzed data."
        )

    elif neutral_pct >= 45:

        mood = "Mostly Neutral"

        explanation = (
            "Neutral reactions make up a large part "
            "of the analyzed data."
        )

    else:

        mood = "Mixed"

        explanation = (
            "The audience response is distributed "
            "across multiple sentiment groups."
        )

    mood_left, mood_right = st.columns(
        [1, 3]
    )

    with mood_left:

        st.metric(
            "Overall Mood",
            mood
        )

    with mood_right:

        st.write(
            explanation
        )

    # ======================================================
    # FEEDBACK EXPLORER
    # ======================================================

    text_column = find_text_column(
        data
    )

    if text_column:

        st.subheader(
            "💬 Feedback Explorer"
        )

        filter_left, filter_right = st.columns(
            2
        )

        # --------------------------------------------------
        # Sentiment Filter
        # --------------------------------------------------

        with filter_left:

            selected_sentiments = st.multiselect(
                "Filter by sentiment",

                [
                    "positive",
                    "neutral",
                    "negative"
                ],

                default=[
                    "positive",
                    "neutral",
                    "negative"
                ]
            )

        # --------------------------------------------------
        # Emotion Filter
        # --------------------------------------------------

        with filter_right:

            if "emotion" in data.columns:

                emotion_options = sorted(
                    data["emotion"]
                    .dropna()
                    .astype(str)
                    .unique()
                    .tolist()
                )

            else:

                emotion_options = []

            selected_emotions = st.multiselect(
                "Filter by emotion",

                emotion_options,

                default=emotion_options
            )

        # --------------------------------------------------
        # Apply Filters
        # --------------------------------------------------

        filtered = data.copy()

        if selected_sentiments:

            filtered = filtered[
                filtered[
                    "sentiment_normalized"
                ].isin(
                    selected_sentiments
                )
            ]

        else:

            filtered = filtered.iloc[0:0]

        if "emotion" in filtered.columns:

            if selected_emotions:

                filtered = filtered[
                    filtered[
                        "emotion"
                    ]
                    .astype(str)
                    .isin(
                        selected_emotions
                    )
                ]

            else:

                filtered = filtered.iloc[0:0]

        # --------------------------------------------------
        # Display Columns
        # --------------------------------------------------

        display_columns = [
            text_column,
            "sentiment"
        ]

        if "emotion" in filtered.columns:

            display_columns.append(
                "emotion"
            )

        for column in [
            "confidence",
            "emotion_score"
        ]:

            if column in filtered.columns:

                display_columns.append(
                    column
                )

        display_columns = [
            column
            for column in display_columns
            if column in filtered.columns
        ]

        st.caption(
            f"Showing "
            f"{min(len(filtered), 200):,}"
            f" of "
            f"{len(filtered):,}"
            " matching records."
        )

        st.dataframe(
            filtered[
                display_columns
            ].head(200),

            use_container_width=True,

            hide_index=True
        )

    # ======================================================
    # COMPLETE DATASET
    # ======================================================

    with st.expander(
        "📋 View complete analyzed dataset"
    ):

        st.dataframe(
            df,

            use_container_width=True,

            hide_index=True
        )

    # ======================================================
    # EXPORT
    # ======================================================

    st.subheader(
        "⬇️ Export"
    )

    st.download_button(

        "Download Analyzed Data",

        data=df.to_csv(
            index=False
        ).encode("utf-8"),

        file_name=(
            "social_media_analysis.csv"
        ),

        mime="text/csv",

        use_container_width=True
    )