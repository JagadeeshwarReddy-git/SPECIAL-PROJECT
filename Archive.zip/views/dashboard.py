from pathlib import Path

import pandas as pd
import streamlit as st
import plotly.express as px


# ==========================================================
# DASHBOARD V2
# Clean, compact, visual analytics dashboard
# ==========================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent
METRICS_FILE = PROJECT_ROOT / "evaluation" / "evaluation_metrics.csv"


# ==========================================================
# HELPERS
# ==========================================================

def normalize_sentiment(value):
    value = str(value).strip().lower()

    if value in ("positive", "pos"):
        return "Positive"

    if value in ("negative", "neg"):
        return "Negative"

    if value in ("neutral", "neu"):
        return "Neutral"

    return value.title()


def format_percent(value):
    if value is None:
        return "—"

    try:
        value = float(value)
    except (TypeError, ValueError):
        return "—"

    if value <= 1:
        value *= 100

    return f"{value:.2f}%"


def load_model_metrics():
    if not METRICS_FILE.exists():
        return {}

    try:
        df = pd.read_csv(METRICS_FILE)
    except Exception:
        return {}

    result = {}

    for _, row in df.iterrows():

        if len(row) < 2:
            continue

        key = str(row.iloc[0]).strip().lower()

        try:
            value = float(row.iloc[1])
        except (TypeError, ValueError):
            continue

        result[key] = value

    return result


def chart_layout(fig, height=280):
    fig.update_layout(
        height=height,
        margin=dict(
            l=10,
            r=10,
            t=50,
            b=15
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(size=11),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0
        )
    )

    return fig


# ==========================================================
# MAIN PAGE
# ==========================================================

def show():

    # ------------------------------------------------------
    # CURRENT ANALYSIS
    # ------------------------------------------------------

    df = st.session_state.get("analysis_df")

    # ------------------------------------------------------
    # EMPTY STATE
    # ------------------------------------------------------

    if (
        df is None
        or not isinstance(df, pd.DataFrame)
        or df.empty
    ):

        st.title("📊 Social Media Analytics Dashboard")

        st.caption(
            "Analyze YouTube comments, text, or CSV data to see "
            "your audience dashboard."
        )

        st.info(
            "📂 No analysis is available yet. "
            "Start an analysis from YouTube Analyzer, "
            "Text Analyzer, or CSV Upload."
        )

        return

    data = df.copy()

    # ------------------------------------------------------
    # REQUIRED DATA
    # ------------------------------------------------------

    if "sentiment" not in data.columns:

        st.title("📊 Social Media Analytics Dashboard")

        st.error(
            "The current analysis does not contain sentiment results."
        )

        return

    # ------------------------------------------------------
    # SENTIMENT PREPARATION
    # ------------------------------------------------------

    data["dashboard_sentiment"] = (
        data["sentiment"]
        .apply(normalize_sentiment)
    )

    total = len(data)

    positive = int(
        (
            data["dashboard_sentiment"]
            == "Positive"
        ).sum()
    )

    neutral = int(
        (
            data["dashboard_sentiment"]
            == "Neutral"
        ).sum()
    )

    negative = int(
        (
            data["dashboard_sentiment"]
            == "Negative"
        ).sum()
    )

    positive_pct = positive / total * 100
    neutral_pct = neutral / total * 100
    negative_pct = negative / total * 100

    dominant_sentiment = (
        data["dashboard_sentiment"]
        .value_counts()
        .idxmax()
    )

    # ------------------------------------------------------
    # EMOTION PREPARATION
    # ------------------------------------------------------

    if "emotion" in data.columns:

        emotions = (
            data["emotion"]
            .astype(str)
            .str.strip()
            .str.title()
        )

        emotions = emotions[
            ~emotions.isin(
                [
                    "",
                    "Nan",
                    "None",
                    "Unknown"
                ]
            )
        ]

    else:

        emotions = pd.Series(dtype=str)

    if not emotions.empty:

        emotion_counts = (
            emotions
            .value_counts()
            .reset_index()
        )

        emotion_counts.columns = [
            "Emotion",
            "Records"
        ]

        dominant_emotion = (
            emotion_counts.iloc[0]["Emotion"]
        )

    else:

        emotion_counts = pd.DataFrame(
            columns=["Emotion", "Records"]
        )

        dominant_emotion = "N/A"

    # ======================================================
    # HEADER
    # ======================================================

    header_left, header_right = st.columns(
        [4, 1]
    )

    with header_left:

        st.title(
            "📊 Social Media Analytics Dashboard"
        )

        st.caption(
            "A compact view of audience sentiment, emotions, "
            "model performance and analysis results."
        )

    with header_right:

        st.metric(
            "Records Analyzed",
            f"{total:,}"
        )

    # ======================================================
    # KPI ROW
    # ======================================================

    st.markdown("### 📌 Audience Snapshot")

    k1, k2, k3, k4, k5 = st.columns(5)

    with k1:

        st.metric(
            "📊 Total",
            f"{total:,}"
        )

    with k2:

        st.metric(
            "😊 Positive",
            f"{positive_pct:.1f}%",
            f"{positive:,} records"
        )

    with k3:

        st.metric(
            "😐 Neutral",
            f"{neutral_pct:.1f}%",
            f"{neutral:,} records"
        )

    with k4:

        st.metric(
            "😟 Negative",
            f"{negative_pct:.1f}%",
            f"{negative:,} records"
        )

    with k5:

        st.metric(
            "🎭 Top Emotion",
            dominant_emotion
        )

    # ======================================================
    # MAIN VISUAL AREA
    # ======================================================

    st.markdown("### 📈 Audience Analysis")

    chart_left, chart_right = st.columns(
        2
    )

    # ------------------------------------------------------
    # SENTIMENT DONUT
    # ------------------------------------------------------

    with chart_left:

        sentiment_df = pd.DataFrame(
            {
                "Sentiment": [
                    "Positive",
                    "Neutral",
                    "Negative"
                ],

                "Records": [
                    positive,
                    neutral,
                    negative
                ]
            }
        )

        fig = px.pie(
            sentiment_df,
            names="Sentiment",
            values="Records",
            hole=0.58,
            title="😊 Audience Sentiment",
            color="Sentiment",
            color_discrete_map={
                "Positive": "#22c55e",
                "Neutral": "#f59e0b",
                "Negative": "#ef4444"
            }
        )

        fig.update_traces(
            textinfo="percent+label",
            textposition="outside"
        )

        st.plotly_chart(
            chart_layout(fig),
            use_container_width=True
        )

    # ------------------------------------------------------
    # EMOTION BAR
    # ------------------------------------------------------

    with chart_right:

        if not emotion_counts.empty:

            display_emotions = (
                emotion_counts
                .head(7)
                .sort_values("Records")
            )

            fig = px.bar(
                display_emotions,
                x="Records",
                y="Emotion",
                orientation="h",
                text="Records",
                title="🎭 Audience Emotions",
                color="Records",
                color_continuous_scale="Turbo"
            )

            fig.update_traces(
                textposition="outside"
            )

            fig.update_layout(
                coloraxis_showscale=False
            )

            st.plotly_chart(
                chart_layout(fig),
                use_container_width=True
            )

        else:

            st.info(
                "🎭 Emotion results are not available "
                "for this analysis."
            )

    # ======================================================
    # AUDIENCE SUMMARY
    # ======================================================

    st.markdown("### 🧠 Audience Summary")

    summary_left, summary_mid, summary_right = st.columns(3)

    with summary_left:

        if positive > negative:

            st.success(
                "### 😊 Positive Mood\n\n"
                "Positive reactions currently lead "
                "the audience response."
            )

        elif negative > positive:

            st.error(
                "### 😟 Negative Mood\n\n"
                "Negative reactions currently lead "
                "the audience response."
            )

        else:

            st.info(
                "### ⚖️ Balanced Mood\n\n"
                "Positive and negative reactions "
                "are currently balanced."
            )

    with summary_mid:

        st.info(
            f"### 🎯 Dominant Sentiment\n\n"
            f"**{dominant_sentiment}** is the most "
            f"frequent sentiment in the analyzed data."
        )

    with summary_right:

        st.info(
            f"### 🎭 Dominant Emotion\n\n"
            f"**{dominant_emotion}** is the most "
            f"frequently detected emotion."
        )

    # ======================================================
    # MODEL PERFORMANCE + SENTIMENT COMPARISON
    # ======================================================

    bottom_left, bottom_right = st.columns(
        [1, 1.35]
    )

    # ------------------------------------------------------
    # MODEL PERFORMANCE
    # ------------------------------------------------------

    with bottom_left:

        st.markdown("### 🧪 Model Performance")

        metrics = load_model_metrics()

        if metrics:

            accuracy = next(
                (
                    value
                    for key, value
                    in metrics.items()
                    if "accuracy" in key
                ),
                None
            )

            precision = next(
                (
                    value
                    for key, value
                    in metrics.items()
                    if "precision" in key
                ),
                None
            )

            recall = next(
                (
                    value
                    for key, value
                    in metrics.items()
                    if "recall" in key
                ),
                None
            )

            f1 = next(
                (
                    value
                    for key, value
                    in metrics.items()
                    if "f1" in key
                ),
                None
            )

            m1, m2 = st.columns(2)

            with m1:

                st.metric(
                    "Accuracy",
                    format_percent(accuracy)
                )

                st.metric(
                    "Recall",
                    format_percent(recall)
                )

            with m2:

                st.metric(
                    "Precision",
                    format_percent(precision)
                )

                st.metric(
                    "Weighted F1",
                    format_percent(f1)
                )

            st.caption(
                "Based on the project's evaluation dataset."
            )

        else:

            st.info(
                "Model evaluation results are not available."
            )

    # ------------------------------------------------------
    # SENTIMENT COMPARISON
    # ------------------------------------------------------

    with bottom_right:

        st.markdown(
            "### 📊 Sentiment Comparison"
        )

        fig = px.bar(
            sentiment_df,
            x="Sentiment",
            y="Records",
            text="Records",
            color="Sentiment",
            color_discrete_map={
                "Positive": "#22c55e",
                "Neutral": "#f59e0b",
                "Negative": "#ef4444"
            }
        )

        fig.update_traces(
            textposition="outside"
        )

        fig.update_layout(
            showlegend=False
        )

        st.plotly_chart(
            chart_layout(fig, 250),
            use_container_width=True
        )

    # ======================================================
    # COMPACT FOOTER ACTIONS
    # ======================================================

    st.divider()

    action_left, action_right = st.columns(
        [4, 1]
    )

    with action_left:

        with st.expander(
            "💬 View analyzed records",
            expanded=False
        ):

            preferred = [
                "text",
                "comment",
                "comments",
                "content",
                "review",
                "sentiment",
                "emotion",
                "sentiment_score",
                "emotion_score"
            ]

            available = [
                column
                for column in preferred
                if column in data.columns
            ]

            if available:

                st.dataframe(
                    data[available].head(15),
                    use_container_width=True,
                    hide_index=True,
                    height=220
                )

            else:

                st.dataframe(
                    data.head(15),
                    use_container_width=True,
                    hide_index=True,
                    height=220
                )

    with action_right:

        st.markdown("#### ⬇️ Export")

        download_data = (
            data
            .drop(
                columns=[
                    "dashboard_sentiment"
                ],
                errors="ignore"
            )
            .to_csv(
                index=False
            )
        )

        st.download_button(
            "Download CSV",
            data=download_data,
            file_name="social_media_dashboard.csv",
            mime="text/csv",
            use_container_width=True
        )


show_dashboard = show
