import json
from pathlib import Path
from datetime import datetime

import pandas as pd
import streamlit as st

HISTORY_FILE = Path("analysis_history.json")
MAX_HISTORY = 50


def load_history():
    if not HISTORY_FILE.exists():
        return []
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def _write(history):
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=4, ensure_ascii=False)


def save_history(analysis_type, records_count, sentiment, emotion, source_name="Analysis"):
    history = load_history()
    now = datetime.now()
    history.insert(0, {
        "id": now.strftime("%Y%m%d%H%M%S%f"),
        "date": now.strftime("%d %b %Y, %I:%M %p"),
        "type": str(analysis_type),
        "source": str(source_name),
        "records": int(records_count),
        "sentiment": str(sentiment),
        "emotion": str(emotion),
    })
    _write(history[:MAX_HISTORY])


def delete_history_items(ids):
    ids = {str(x) for x in ids}
    _write([x for x in load_history() if str(x.get("id")) not in ids])


def delete_history_item(item_id):
    delete_history_items({item_id})


def clear_history():
    _write([])


def _type_icon(value):
    return {
        "youtube": "📺",
        "text": "📝",
        "csv": "📂",
    }.get(str(value).lower(), "📊")


def _sentiment_icon(value):
    return {
        "positive": "😊",
        "negative": "😟",
        "neutral": "😐",
    }.get(str(value).lower(), "🔎")


def show():
    st.markdown("""
    <style>
    .history-hero {
        padding:24px 28px;border-radius:20px;margin-bottom:22px;color:white;
        background:linear-gradient(135deg,#667eea,#764ba2,#f093fb);
    }
    .history-hero h1{color:white;margin:0;font-size:2.15rem}
    .history-hero p{color:rgba(255,255,255,.9);margin:7px 0 0}
    .hcard{
        border:1px solid rgba(128,128,128,.22);border-radius:16px;
        padding:17px;margin:7px 0;background:rgba(128,128,128,.035);
    }
    .htop{display:flex;justify-content:space-between;gap:15px}
    .hsource{font-size:15px;font-weight:650;margin:10px 0 14px;word-break:break-word}
    .hdetails{display:flex;gap:30px;flex-wrap:wrap}
    .hdetail span{display:block;font-size:11px;opacity:.6}
    .hdetail strong{font-size:13px}
    </style>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="history-hero">
        <h1>🕒 Analysis History</h1>
        <p>View, search, filter and delete your previous analyses.</p>
    </div>
    """, unsafe_allow_html=True)

    history = load_history()

    if not history:
        st.info("🗂️ No analysis history yet. Analyze YouTube, Text or CSV data first.")
        return

    # Summary
    total_records = sum(int(x.get("records", 0)) for x in history)
    positive = sum(str(x.get("sentiment","")).lower() == "positive" for x in history)
    types = len(set(str(x.get("type","Analysis")) for x in history))

    a,b,c,d = st.columns(4)
    a.metric("📚 Saved Analyses", len(history))
    b.metric("📊 Total Records", f"{total_records:,}")
    c.metric("😊 Positive Analyses", positive)
    d.metric("📂 Analysis Types", types)

    st.markdown("### 🔎 Find an Analysis")
    f1,f2,f3 = st.columns([1.5,1,1])

    with f1:
        search = st.text_input("Search", placeholder="Source, type, sentiment, emotion...")
    with f2:
        types_list = ["All"] + sorted(set(str(x.get("type","Analysis")) for x in history))
        selected_type = st.selectbox("Type", types_list)
    with f3:
        selected_sentiment = st.selectbox(
            "Sentiment", ["All","Positive","Neutral","Negative"]
        )

    filtered = []
    for item in history:
        typ = str(item.get("type","Analysis"))
        sentiment = str(item.get("sentiment",""))
        searchable = " ".join([
            typ, str(item.get("source","")), sentiment,
            str(item.get("emotion","")), str(item.get("date",""))
        ]).lower()

        if search.strip() and search.lower() not in searchable:
            continue
        if selected_type != "All" and typ != selected_type:
            continue
        if selected_sentiment != "All" and sentiment.lower() != selected_sentiment.lower():
            continue
        filtered.append(item)

    st.markdown("### 📋 Saved Analyses")
    st.caption(f"Showing {len(filtered)} of {len(history)} saved analyses.")

    if not filtered:
        st.warning("No history items match your filters.")
        return

    select_all = st.checkbox("☑️ Select all visible items")
    selected_ids = []

    for i, item in enumerate(filtered):
        item_id = str(item.get("id", i))
        check_col, card_col = st.columns([0.06, 0.94])

        with check_col:
            checked = st.checkbox(
                "", value=select_all, key=f"history_select_{item_id}"
            )
            if checked:
                selected_ids.append(item_id)

        with card_col:
            typ = str(item.get("type","Analysis"))
            sentiment = str(item.get("sentiment","Unknown"))
            st.markdown(f"""
            <div class="hcard">
                <div class="htop">
                    <div><b>{_type_icon(typ)} {typ}</b></div>
                    <div>🕒 {item.get("date","")}</div>
                </div>
                <div class="hsource">{item.get("source","Unknown source")}</div>
                <div class="hdetails">
                    <div class="hdetail"><span>Records</span><strong>{int(item.get("records",0)):,}</strong></div>
                    <div class="hdetail"><span>Sentiment</span><strong>{_sentiment_icon(sentiment)} {sentiment}</strong></div>
                    <div class="hdetail"><span>Emotion</span><strong>🎭 {item.get("emotion","Unknown")}</strong></div>
                </div>
            </div>
            """, unsafe_allow_html=True)

    st.divider()
    x,y = st.columns(2)

    with x:
        if st.button(
            f"🗑️ Delete Selected ({len(selected_ids)})",
            disabled=not selected_ids,
            use_container_width=True
        ):
            delete_history_items(selected_ids)
            st.rerun()

    with y:
        if st.button("🧹 Clear Entire History", use_container_width=True):
            st.session_state.confirm_clear_history = True

    if st.session_state.get("confirm_clear_history", False):
        st.warning("⚠️ This permanently deletes all saved history.")
        p,q = st.columns(2)
        with p:
            if st.button("Yes, Clear Everything", use_container_width=True):
                clear_history()
                st.session_state.confirm_clear_history = False
                st.rerun()
        with q:
            if st.button("Cancel", use_container_width=True):
                st.session_state.confirm_clear_history = False
                st.rerun()

    st.markdown("### 📊 History Distribution")
    distribution = (
        pd.Series([str(x.get("type","Analysis")) for x in history])
        .value_counts()
        .rename_axis("Analysis Type")
        .to_frame("Count")
    )
    st.bar_chart(distribution, use_container_width=True)


show_history = show
